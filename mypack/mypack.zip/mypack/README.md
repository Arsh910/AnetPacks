# mypack — Recipient README

## What this pack does

**mypack** is a productivity pack that combines Telegram notification, browser automation,
and code-graph analysis into one workspace bundle.

- **tele_tool** (ExTool) + **tele_agent** (ExAgent): send text messages or files
  (photos, videos, audio, documents) to a Telegram chat via a bot. The planner routes
  any Telegram-flavoured task automatically to `tele_agent`.
- **playwright** (MCP): full browser automation via Microsoft's Playwright — navigate,
  click, fill forms, take screenshots, and snapshot pages.
- **codegraph** (MCP): a production-grade code-graph server. Index a project once, then
  query symbols, callers, file trees, and change-impact analysis. Tools exposed over MCP:
  `index`, `sync`, `query`, `context`, `files`, `affected`, `status`.
- **example_skill**: a bundled skill included in the pack.

---

## Prerequisites

| Requirement | Why |
|---|---|
| **Node.js** (v18 +) on PATH | Required by both `playwright` (npx) and `codegraph` (node) |
| **Python** with `httpx` | Required by `tele_tool` — run `pip install httpx` |

---

## Required environment variables

### `ExAgents/tele_agent/.env`
Create this file inside the imported pack folder with the following keys:

```
TELEGRAM_BOT_TOKEN=<your bot token from @BotFather>
TELEGRAM_CHAT_ID=<your chat ID, e.g. from @userinfobot>
```

### `ExTools/tele_tool/.env`
Create this file with the same two keys:

```
TELEGRAM_BOT_TOKEN=<your bot token from @BotFather>
TELEGRAM_CHAT_ID=<your chat ID, e.g. from @userinfobot>
```

How to get them:
1. Open Telegram, search **@BotFather**, send `/newbot`, follow the prompts → copy the token.
2. Search **@userinfobot**, start it → it replies with your numeric chat ID.

---

## MCP servers

### playwright (package-based — no manual setup)
Runs via `npx @playwright/mcp`. As long as Node.js is on your PATH, npx downloads the
package automatically on first run. Playwright may also download browser binaries the
first time — this is normal and automatic.

**Test it:** `python -m anet.core.mcp_doctor playwright`

### codegraph (repo-backed — must clone & build yourself)
> ⚠️ The codegraph source code is **NOT** shipped in this zip (it's a repo-backed project).
> Only its `config.yaml` and this README ship. You must clone and build it yourself.

**Steps (requires Node.js + Git):**
```bash
git clone https://github.com/colbymchenry/codegraph.git
cd codegraph
npm install
npm run build
```

Then open `mcps/codegraph/config.yaml` inside the imported pack and update the `args`
path to point at YOUR built file:

```yaml
command: node
args:
  - /absolute/path/to/your/codegraph/dist/bin/codegraph.js
  - serve
  - --mcp
cwd: "."
```

> **Note on `cwd`:** keep `cwd: "."` — codegraph locates the graph store by walking
> parent directories (like `.git`) and must run inside the indexed project, not a fixed
> data directory.

**Test it:** `python -m anet.core.mcp_doctor codegraph`

---

## Tools & agents

- **tele_tool / tele_agent**: requires `pip install httpx` and the two `.env` files
  described above. No external binary or account beyond a Telegram bot is needed.

---

## Install

1. **Import the pack:**
   `/packsmith add mypack.zip`

2. **Activate it:**
   `/changepack`

---

## Trust note

⚠️ This pack contains runnable code (ExTools and MCP servers). Only install it if you
trust the source — activating it means that code will run in your ANet environment.
