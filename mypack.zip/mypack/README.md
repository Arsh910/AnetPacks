# mypack

## What this pack does

`mypack` adds a Telegram notifier workflow to ANet. It includes the `tele_tool` ExTool, which sends text messages and files to a Telegram chat through the Telegram Bot API, and the `tele_agent` ExAgent, which a planner can route Telegram requests to. The pack also includes two MCP servers: `codegraph`, a local code-graph server for indexing and querying project symbols/callers/files/affected changes, and `playwright`, Microsoft’s Playwright MCP for browser automation.

## Install

1. Add the zip in ANet:

   ```text
   /packsmith add <path-to-this-zip>
   ```

2. Activate it:

   ```text
   /changepack
   ```

## Requires

### Runtime prerequisites

- Node.js on PATH for both MCP servers:
  - `playwright`: required so `npx @playwright/mcp` can run.
  - `codegraph`: required to build and run the local server.
- Python/ANet environment with `anet.core.mcp_doctor` available if you want to test MCP servers.
- For `tele_tool`: Python package `httpx` must be installed in the environment that runs ANet/tools.

### Telegram environment variables

Create or edit this file after installing the pack:

```text
ExAgents/tele_agent/.env
```

Add:

```text
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

Notes:

- Create a Telegram bot and get `TELEGRAM_BOT_TOKEN` from `@BotFather`.
- Get `TELEGRAM_CHAT_ID` from a helper such as `@userinfobot` or another Telegram user-info bot.
- The pack’s `.env` files and secrets are not included in the shared zip.

## MCP servers

### codegraph

`codegraph` is a repo-backed/vendored MCP server. Its code is **not shipped** in this zip; only `mcps/codegraph/config.yaml` and its README are included. You must obtain and build it on your machine, then point the config at your built entry file.

Obtain and build:

```bash
git clone https://github.com/colbymchenry/codegraph.git
cd codegraph
npm install
npm run build
```

Expected entry command/args:

```text
command: node
args:
  - /absolute/path/to/your/codegraph/dist/bin/codegraph.js
  - serve
  - --mcp
cwd: "."
```

Edit `mcps/codegraph/config.yaml` so the `args` point to your built `dist/bin/codegraph.js` on your machine. Keep `cwd: "."` because codegraph stores graph data relative to the indexed project root.

Test after activation:

```bash
python -m anet.core.mcp_doctor codegraph
```

### playwright

`playwright` is package-based. Nothing is cloned or built manually.

Expected runtime:

```text
command: npx
args:
  - @playwright/mcp
```

You only need Node.js on PATH. On first run, `npx` fetches `@playwright/mcp`; Playwright may also download browser binaries automatically.

Test after activation:

```bash
python -m anet.core.mcp_doctor playwright
```

## Tools & agents

### ExTool: tele_tool

Sends text messages or files to a Telegram chat via the Telegram Bot API.

External dependency:

```bash
pip install httpx
```

Environment is set in `ExAgents/tele_agent/.env` as described above.

### ExAgent: tele_agent

A notifier agent that sends messages and files to Telegram using `tele_tool`. The planner routes Telegram requests to this agent via its task types.

Environment is set in `ExAgents/tele_agent/.env`:

```text
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

## Trust note

This pack contains runnable ANet code, including tools and MCP server configuration. Only add/activate it if you trust the pack source and the MCP servers it configures.