# mypack — Telegram Notification Pack

## What this pack does
This pack wires up an ANet workspace with **Telegram messaging capabilities**. It includes a Telegram tool (`tele_tool`) and a Telegram agent (`tele_agent`) that together allow ANet to send messages, notifications, or alerts to a Telegram chat via a bot. It also bundles a `wordcount` ExTool for text analysis, a `codegraph` MCP server for code structure visualisation, a `playwright` MCP server for browser automation, and an `example_skill` to demonstrate the skill system.

---

## Requires

### Environment Variables
You must create the following `.env` files **inside the imported pack folder** (`shared_packs/mypack/`) after running `/packsmith add`:

**`ExAgents/tele_agent/.env`**
```
TELEGRAM_BOT_TOKEN=your-telegram-bot-token-here
TELEGRAM_CHAT_ID=your-telegram-chat-id-here
```

**`ExTools/tele_tool/.env`**
```
TELEGRAM_BOT_TOKEN=your-telegram-bot-token-here
TELEGRAM_CHAT_ID=your-telegram-chat-id-here
```

To obtain these values:
- **TELEGRAM_BOT_TOKEN**: Create a bot via [@BotFather](https://t.me/BotFather) on Telegram and copy the token it gives you.
- **TELEGRAM_CHAT_ID**: Send a message to your bot, then call `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` to find your chat ID.

### Prerequisites
- **Python 3.9+** — required for ANet ExTools/ExAgents.
- **Node.js 18+** (`node` / `npx` on your PATH) — required by the `codegraph` and `playwright` MCP servers, which are launched via `npx`.
- **Playwright browsers** — after installing, run `npx playwright install` if the `playwright` MCP needs browser binaries.

---

## Install

1. **Add the pack:**
   ```
   /packsmith add mypack.zip
   ```
   Packsmith will walk you through setting your secrets interactively.

2. **Activate the pack:**
   ```
   /changepack
   ```
   Select `mypack` from the list.

---

## Contents at a Glance

| Type | Name | Purpose |
|------|------|---------|
| ExTool | `tele_tool` | Send Telegram messages from any agent or workflow |
| ExTool | `wordcount` | Count words / analyse text |
| ExAgent | `tele_agent` | Autonomous agent with Telegram messaging built in |
| MCP | `codegraph` | Code structure & dependency graph visualisation |
| MCP | `playwright` | Browser automation via Playwright |
| Skill | `example_skill` | Demonstrates the ANet skill system |

---

## Trust Note
⚠️ This pack contains **runnable code** (ExTools, ExAgents, and MCP servers). By activating it with `/changepack` you are trusting that code to execute in your ANet environment. Review the source in `shared_packs/mypack/` before activating if you have any concerns.
